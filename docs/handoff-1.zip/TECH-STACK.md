# Kitchen Terminal K7 — założenia techniczne

## Stack

| Warstwa | Wybór |
|---|---|
| Język | TypeScript 7 (natywny kompilator Go — RC w czerwcu 2026, powinien być GA) |
| Bundler | Vite 8 |
| Frontend framework | Svelte lub czysty HTML — **do ustalenia** (patrz niżej) |
| Meta-framework | Astro |
| Komponenty | Web Components (custom elements) |
| Style | Tailwind CSS, klasy grupowane w mixiny (`@apply`/warstwa komponentowa) |
| Storybook | tak, osobny build |
| Architektura backendu | heksagonalna (ports & adapters), dependency injection |
| PWA | pełny cache offline (Service Worker, app shell + dane) |
| Kompatybilność | iPad Air 2 (A1567) i iPhone 6s — oba wspierane do iOS/iPadOS 15, więc wspólny baseline to Safari 15 |
| Zarządzanie credentiali | Varlock (dmno-dev/varlock) — schema-based `.env`, walidacja i typowanie, redakcja sekretów w logach, skanowanie wycieków, integracje z 1Password/Infisical/AWS/Vault; agenci AI widzą schemat, nigdy realnych wartości |

## Biblioteki własne i zewnętrzne

- **config-layers** (github.com/mt3o/config-layers) — Twoja biblioteka, warstwowa konfiguracja
- **middleware-pipe** (github.com/mt3o/middlewares) — Twoja biblioteka, kompozycja middleware ze
  statyczną walidacją (Zod). **Do publikacji na npm** — patrz zastrzeżenie niżej
- **@logosdx/\*** (github.com/logosdx/monorepo) — gotowe pakiety npm: `utils`, `observer`,
  `fetch`, `storage`, `dom`, `localize` — TypeScript-first, zero-dependency, runtime-agnostic,
  pasują dobrze do heksagonalnej architektury jako adaptery (fetch z retry, storage jako
  jeden interfejs na wiele backendów kluczy-wartości, obserwator zdarzeń)
- **agentic-memory-system** i **graph-workflow** (mt3o-dev) — do zarządzania kontekstem
  (chatu?) — **patrz zastrzeżenie niżej, to nie jest biblioteka runtime**
- **vidataflux** (mt3o-dev) — do zarządzania danymi, wymaga pakietu na npm — **patrz
  zastrzeżenie niżej, repo jest puste**

## ⚠️ Zastrzeżenia — status

1. **`middleware-pipe` — nazwa zajęta na npm.** Potwierdzone, poszukasz innej nazwy.
   Na razie trzymam w dokumentacji adres repo (github.com/mt3o/middlewares) bez
   zmian — nazwa pakietu npm do ustalenia później.
2. **`agentic-memory-system` i `graph-workflow` — potwierdzone: narzędzia do PRACY
   nad projektem** (Ty + Claude Code), nie zależności runtime aplikacji. Nie trafiają
   do `package.json` — zostają jako narzędzia deweloperskie obok projektu.
3. **`vidataflux` — puste repo, do uzupełnienia przez Ciebie** przed użyciem w stacku.
4. ~~iPhone 6s vs. iPad~~ — rozwiązane, patrz wyżej (oba do iOS/iPadOS 15).

## Decyzje oddane Opusowi (do rozstrzygnięcia w Fazie 0)

### Svelte vs. czysty HTML
Dane wejściowe do decyzji: Svelte 5 kompiluje się do JS bez Virtual DOM i bez
runtime'u frameworka — minimalna aplikacja waży ~2–5 KB gzip (dla porównania
React+ReactDOM to ~40–45 KB), czas do interaktywności zwykle 30–40% szybszy niż
w frameworkach z VDOM. Na sprzęcie klasy A8X/2GB RAM (iPad Air 2) narzut Svelte
względem czystego JS jest w praktyce pomijalny, przy zachowaniu dużo lepszego DX
(komponenty, reaktywność, mniej kodu). Opus ma to potwierdzić/zdecydować ostatecznie
biorąc pod uwagę też architekturę heksagonalną i Web Components (Svelte 5 umie
kompilować komponenty do custom elements przez `<svelte:options customElement>`).

### Baza danych: SQLite + adapter migracji + prosty ORM
Ustalone: SQLite jako silnik bazy. Do zdecydowania przez Opusa: konkretny adapter
migracji i lekki ORM/query builder pasujący do architektury heksagonalnej (repozytorium
powinno dać się łatwo podmienić za portem) i do TypeScript-first stacku. Kandydaci
do rozważenia (nie ostateczna decyzja): Drizzle ORM (lekki, TS-first, drizzle-kit do
migracji), Kysely (query builder z pełnym typowaniem, jeszcze mniej narzutu niż
pełny ORM), ewentualnie better-sqlite3 jako sterownik niskopoziomowy pod spodem.


## Decyzje (rozstrzygnięte)

### Frontend: Svelte + Web Components
Zdecydowane: Svelte 5, komponenty eksportowane jako custom elements
(`<svelte:options customElement="...">`) zamiast czystego natywnego JS. Dane, które
za tym stały: Svelte kompiluje się do JS bez Virtual DOM i bez runtime'u frameworka —
minimalna aplikacja waży ~2–5 KB gzip (dla porównania React+ReactDOM to ~40–45 KB),
czas do interaktywności zwykle 30–40% szybszy niż w frameworkach z VDOM. Na sprzęcie
klasy A8X/2GB RAM (iPad Air 2) narzut względem czystego JS jest w praktyce pomijalny,
przy zachowaniu dużo lepszego DX.

### Baza danych: SQLite
Silnik zdecydowany: SQLite. Otwarty pozostaje tylko konkretny adapter migracji i
lekki ORM/query builder (patrz sekcja "Decyzje oddane Opusowi" niżej) — nie sam
wybór silnika.

## Otwarte decyzje

1. ~~Framework frontendu~~ — rozstrzygnięte: Svelte + Web Components (patrz wyżej)
2. Nazwa repo na GitHubie — ustalona: **kitchen-terminal-k7**

## Zaktualizowana Faza 0 (dodatki)

- [ ] Rozstrzygnąć pozostałe 3 zastrzeżenia powyżej z Tobą (nazwa pakietu, memory-system/graph-workflow, vidataflux) — **blokuje start**
- [ ] Wybór adaptera migracji + lekkiego ORM/query buildera do SQLite (silnik już ustalony) — **Opus**
- [ ] Ustawić target kompilacji (`tsconfig`/Vite `build.target`) zgodnie z finalnie
      ustalonym urządzeniem docelowym (patrz zastrzeżenie 4) — **Sonnet**
- [ ] Zmiana nazwy pakietu `middleware-pipe` przed publikacją na npm — **Haiku**
      (wymaga Twojej decyzji co do nowej nazwy)
- [ ] Konfiguracja Service Workera pod pełny cache offline (workbox lub ręczny SW) — **Opus**
      (strategia cache'owania danych dynamicznych — kalendarz, przepisy — różni się od
      cache'owania app shell; wymaga przemyślenia inwalidacji)
- [ ] Setup Varlock: `.env.schema` z typowanymi/wymaganymi zmiennymi (Kilo Gateway key,
      Google OAuth refresh token, GlitchTip DSN) i redakcją w logach — **Sonnet**
      (szczególnie ważne przy czacie AI z logowaniem wywołań — sekrety nie mogą trafić
      do logów GlitchTip razem z błędami)
