# Kuchnia Dashboard — plan projektu

Retro-futurystyczny dashboard kuchenny na starym iPadzie (Safari, "Add to Home
Screen"), backend na fizycznym serwerze w domowym LAN. Pogoda, kalendarz Google
(dwukierunkowo), przepisy (import z URL), lista zakupów, timer, czat AI przez
Kilo Gateway, "kot dnia" (ASCII-art generowany przez AI zamiast scrapowania
cudzego contentu).

## Architektura (skrót)

- **Backend**: Node.js/TypeScript, Express lub Fastify
- **Frontend**: statyczna strona (Astro lub vanilla) serwowana z tego samego
  backendu, styl retro-scifi (monospace, amber/teal, ostre kąty)
- **DB**: SQLite (lekko, pasuje do jednej maszyny w LAN) — tabele: `recipes`,
  `shopping_list`, `ai_calls`, `conversations`, `messages`
- **Integracje**: Google Calendar API (OAuth2), Kilo Gateway
  (`https://api.kilo.ai/api/gateway`), Open-Meteo (pogoda), GlitchTip (SDK
  `@sentry/node`, kompatybilny 1:1)
- **Repo**: publiczne na GitHubie, CI podobne do ytshield/punktomat
- **Storybook**: osobny build komponentów UI (karty, timer, chat, kalendarz)

## Otwarte decyzje (do potwierdzenia przed startem)

1. Framework frontendu: Astro vs vanilla JS — Astro daje SSR i pasuje do
   Twojego stacku, ale to jeden ekran, więc vanilla może być prostsze
2. Nazwa repo na GitHubie
3. Czy SQLite wystarczy na start, czy od razu Postgres (jeśli planujesz więcej
   urządzeń/klientów w przyszłości)

## Fazy i zadania

Model dobrany do złożoności/wpływu zadania (Haiku = proste/niskie ryzyko,
Sonnet = umiarkowane, Opus = złożone/decyzje architektoniczne).

### Faza 0 — szkielet projektu
- [ ] Decyzja: Svelte vs. czysty HTML (patrz TECH-STACK.md) — **Opus**
- [ ] Decyzja: adapter migracji + lekki ORM/query builder do SQLite (patrz TECH-STACK.md) — **Opus**
- [ ] Scaffold repo (struktura folderów, tsconfig, eslint, package.json) — **Haiku**
- [ ] CI: lint + build na GitHub Actions — **Haiku**
- [ ] Setup GlitchTip SDK (init, test error) — **Haiku**
- [ ] Setup Storybook (konfiguracja, pierwszy przykładowy komponent) — **Sonnet**
- [ ] Szkielet bazy SQLite + migracje (schemat tabel) — **Sonnet**

### Faza 1 — dashboard statyczny (bez AI)
- [ ] Wydzielenie tokenów designu do pliku motywu (`theme.schema.yaml`) — **Sonnet**
      (komponenty czytają zmienne CSS wygenerowane z motywu, nie kolory/fonty na sztywno)
- [ ] Loader motywu: wczytuje plik z `theme` wskazanego w `layout.yaml`, generuje CSS vars — **Sonnet**
- [ ] Layout retro-scifi: siatka, typografia, tokeny kolorów — **Sonnet**
- [ ] Komponent: karta pogody (Open-Meteo, fetch + render) — **Haiku**
- [ ] Komponent: timer kuchenny (czysty JS, offline) — **Haiku**
- [ ] Komponent: widok tygodnia kalendarza (na razie mockowane dane) — **Sonnet**
- [ ] Storybook stories dla powyższych komponentów — **Haiku**

### Faza 2 — Google Calendar (dwukierunkowo)
- [ ] Rejestracja aplikacji w Google Cloud Console, OAuth consent — **Sonnet**
      (wymaga Twojej ręcznej interakcji w konsoli Google)
- [ ] Backend: flow OAuth2 + przechowywanie refresh tokena — **Opus**
      (bezpieczeństwo tokenów, decyzja architektoniczna)
- [ ] Endpointy: lista wydarzeń tygodnia, dodaj, edytuj, usuń — **Sonnet**
- [ ] Podłączenie widoku tygodnia do prawdziwych danych — **Sonnet**

### Faza 3 — przepisy i lista zakupów
- [ ] Parser `schema.org/Recipe` (JSON-LD) z URL — **Sonnet**
- [ ] Fallback heurystyczny (Readability.js + wykrywanie listy składników) — **Opus**
      (niejednoznaczne dane wejściowe, wymaga projektowania heurystyki)
- [ ] Endpoint `POST /recipes/import` + ekran potwierdzenia importu — **Sonnet**
- [ ] CRUD listy zakupów (backend + prosty UI) — **Haiku**

### Faza 4 — czat AI (Kilo Gateway)
- [ ] Integracja z `GET /api/gateway/models` (lista modeli + cennik + context window) — **Sonnet**
- [ ] `ConversationService`: rolling window + budżetowanie kontekstu per model — **Opus**
      (kluczowa decyzja architektoniczna, wpływa na przyszłe MCP/skill)
- [ ] Compacting: streszczanie starszej historii tańszym modelem — **Opus**
- [ ] Endpoint czatu (SSE streaming) + UI z wyborem modelu — **Sonnet**
- [ ] Logowanie wywołań: tokeny, koszt, sesja → tabela `ai_calls` — **Sonnet**
- [ ] Dashboard/log przegląda historii kosztów (prosty widok) — **Haiku**

### Faza 5 — kot dnia
- [ ] Prompt + endpoint generujący ASCII-art kota (Kilo Gateway) — **Haiku**
- [ ] Cache na dzień (nie generować przy każdym odświeżeniu) — **Haiku**

### Faza 6 — deployment i twarde detale iPada
- [ ] Reverse proxy / HTTPS w LAN (jeśli iPad wymaga; Safari bywa marudne co do mixed content) — **Sonnet**
- [ ] Instrukcja "Add to Home Screen" + ustawienia Auto-Lock: Never — **Haiku**
- [ ] Test na faktycznym starym iOS (Safari renderowanie, JS wsparcie) — **Sonnet**

## Kolejność pracy

Zgodnie z Twoim stylem (plan-first, przegląd w GUI): każda faza kończy się
czymś widocznym do obejrzenia przed przejściem dalej — Storybook dla
komponentów, realny ekran na iPadzie dla integracji.
