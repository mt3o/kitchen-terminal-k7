# Kuchnia Dashboard — handoff

Dokument dla przyszłej sesji (Claude lub Ciebie), żeby nie trzeba było
odtwarzać kontekstu od zera.

## Kontekst sprzętowy

- Stary iPad (~10 lat, prawdopodobnie iOS 9–10) jako kiosk kuchenny
- Montowany na stałe (uchwyt/stojak), podłączony do zasilania na stałe
- Dostęp przez Safari → "Add to Home Screen" (pełny ekran, bez paska adresu)
- Auto-Lock ustawiony na Never
- Ograniczenie: stary Safari — nie polegać na najnowszych API JS,
  testować wcześnie i często na realnym urządzeniu

## Kontekst sieciowy

- Backend na fizycznej maszynie w domowym LAN (nie na cloud VPS, który Teodor
  ma osobno do innych projektów)
- iPad i serwer w tej samej sieci — nie trzeba wystawiać na zewnątrz,
  ale HTTPS w LAN bywa problematyczne dla starego Safari (mixed content,
  self-signed certy) — do sprawdzenia w fazie deploymentu

## Decyzje stylistyczne (ustalone)

- Styl: retro-futurystyczny, mocny klimat sci-fi (nie subtelny terminal)
- Typografia: monospace
- Kolory: amber jako dominujący akcent + teal jako drugi
- Kształty: ostre kąty (border-radius: 0), grube obramowania jako "HUD"
- Elementy: migający kursor, etykiety w stylu diagnostycznym
  (`STATUS: ONLINE`, `[AKTYWNE]`, `>> log`)
- Dwa wireframe'y zaakceptowane kierunkowo — patrz `wireframes/`

## Funkcje i status decyzji

| Funkcja | Status | Notatka |
|---|---|---|
| Pogoda | zdecydowane | Open-Meteo, bez klucza API |
| Kalendarz Google | zdecydowane | dwukierunkowo: odczyt + dodaj/edytuj/usuń, mini widok tygodnia |
| Przepisy | zdecydowane | import przez URL, ekstrakcja (schema.org/Recipe + fallback) |
| Lista zakupów | zdecydowane | edytowalna też z telefonu |
| Timer | zdecydowane | czysty JS, offline |
| Czat AI | zdecydowane | Kilo Gateway, wybór modelu, do bieżących pytań; docelowo możliwe podpięcie pod MCP/dedykowany skill — stąd `ConversationService` ma być oddzielony od endpointu czatu |
| Baza błędów | zdecydowane | GlitchTip, SDK `@sentry/node` (kompatybilny) |
| Repo | zdecydowane | publiczne na GitHubie |
| Storybook | zdecydowane | osobny build komponentów |
| Logowanie AI | zdecydowane | tabela `ai_calls`: sesja, model, tokeny, szacowany koszt |
| Rolling window / compacting | zdecydowane | budżet kontekstu per model na podstawie `contextWindow` z listy modeli Kilo Gateway |
| Theming | zdecydowane | design podmieniany przez wczytanie innego pliku motywu (`theme.schema.yaml`); komponenty czytają wyłącznie tokeny/zmienne CSS, nigdy nie zaszywają kolorów/fontów na sztywno |
| Mikrofon w czacie | zdecydowane | ikona nagrywania + transkrypcja audio przed wysłaniem wiadomości |
| Karuzela / grid w karcie / slideshow bezczynności | zdecydowane | `carousel` = ręczne/auto przewijanie slajdów w jednej pozycji siatki (z `startDelaySeconds`); `grid` = zagnieżdżona mini-siatka widoczna naraz; `slideshow` = pełnoekranowa rotacja głównych kart po `idleTriggerSeconds` bezczynności, przerywana dotykiem |
| Kot dnia | zmienione | rozdzielone na dwa osobne widgety: `comic-of-the-day` (zewnętrzny obraz z RSS, atrybucja, filtrowanie słów kluczowych) i `ascii-art-of-the-day` (generowany przez AI, własny prompt/model/rozmiar) — inne parametry i inne kwestie prawne, więc nie warto ich łączyć w jeden typ |

## Techniczne notatki, które łatwo przeoczyć

- Kilo Gateway: base URL `https://api.kilo.ai/api/gateway/`, format modelu
  `provider/model-name`, lista modeli i cennik przez `GET /models` (bez
  autoryzacji), `usage.prompt_tokens`/`completion_tokens` w odpowiedzi do
  liczenia kosztu
- Google Calendar: pełna integracja dwukierunkowa wymaga OAuth2, nie tylko
  publicznego `.ics` (to tylko odczyt)
- Refresh token Google i klucz Kilo Gateway — nigdy nie trafiają do frontendu/iPada,
  tylko backend

## Co dalej

Zacząć od Fazy 0 w `PLAN.md` (szkielet repo) — wymaga Twojej decyzji co do
frameworka frontendu i nazwy repo (patrz "Otwarte decyzje" w planie) zanim
ruszy scaffolding.
